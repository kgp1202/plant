boolean = {
no: no underbar
yes: yes underbar
},
opacity;

filename = "%s_%d", boolean, opacity;